package tn.esprit.rh.achat.entities;

public enum CategorieFournisseur {
ORDINAIRE,CONVENTIONNE
}
